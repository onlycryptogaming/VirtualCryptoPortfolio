# CryptoClassroom

Virtual crypto trading simulator for classrooms. Built with Next.js 14 + Supabase.
No Google Sheets required — all data lives in Supabase.

## Quick Start

### 1. Install
```bash
npm install
```

### 2. Set up Supabase
1. supabase.com → create free project
2. SQL Editor → paste `supabase/schema.sql` → Run
3. Settings → API → copy URL, anon key, service_role key

### 3. Google OAuth
1. console.cloud.google.com → OAuth 2.0 credentials
2. Redirect URI: `https://your-domain.vercel.app/api/auth/callback/google`

### 4. Environment
```bash
cp .env.example .env.local
# Fill in all values
```

### 5. Add first student (Supabase SQL Editor)
```sql
insert into students (name, email) values ('Bob Reasey', 'rnreasey@southfayette.org');
insert into portfolios (student_id, cash)
  select id, 10000 from students where email = 'rnreasey@southfayette.org';
```

### 6. Run locally
```bash
npm run dev
```

### 7. Deploy
Push to GitHub → Vercel auto-deploys. Add env vars in Vercel dashboard.

## Pages
| Route | Description |
|-------|-------------|
| / | Login |
| /dashboard | Student portfolio + trading |
| /leaderboard | Live standings |
| /market | Price table |
| /badges | Achievement badges |
| /teacher | Teacher controls + settings |

## Environment Variables
See `.env.example` for all required values.
